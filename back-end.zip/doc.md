Fayllarni linux serverga yuklangandan keyin ushbu amallarni bajarish orqali dasturni ishga tushirish mumkin.

1. mongodb urlini .env fileni ichiga joylashtirish kerak.

# run command

2. npm i
3. npm start
